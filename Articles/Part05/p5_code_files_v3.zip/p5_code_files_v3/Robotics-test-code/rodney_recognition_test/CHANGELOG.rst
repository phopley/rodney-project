^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rodney_recognition_test
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.0 (2019-01-24)
------------------
* Test now Python script instead of C++ executable

0.1.0 (2018-08-16)
------------------
* First formal release of the package
