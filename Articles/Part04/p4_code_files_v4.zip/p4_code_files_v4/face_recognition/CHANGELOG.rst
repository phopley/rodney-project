^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package face_recognition
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2019-01-10)
------------------
* Now using compressed images in the topics
* Now using an Action to control the process

0.1.2 (2018-08-07)
------------------
* Minor comment change
* Update email address in package.xml file
* In training.py load gray scale image directly
* Updates to standardise README.md

0.1.1 (2018-06-24)
------------------
* Updated test.launch to include raspicam and republish node

0.1.0 (2018-06-14)
------------------
* First formal release of the package
