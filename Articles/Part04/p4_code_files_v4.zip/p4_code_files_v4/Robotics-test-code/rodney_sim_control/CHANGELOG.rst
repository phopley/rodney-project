^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package joystick
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.0 (2019-01-12)
------------------
* Change to head pan/tilt joint names

0.1.0 (2018-11-12)
------------------
* First formal release of the package
