^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for Robotics-test-code
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2019-01-24)
------------------
* Updated rodney_sim_control package to 0.3.0

0.0.3 (2019-01-13)
------------------
* Added odom_test 0.1.0
* Updated rodney_head_test package to 0.2.0
* Added rodney_object_test package 0.1.0
* Updated rodney_recognition_test package to 0.2.0
* Updated rodney_sim_control package to 0.2.0

0.0.2 (2018-11-12)
------------------
* Added speech test and Gazebo model

0.0.1 (2018-08-16)
------------------
* First formal release of the package
