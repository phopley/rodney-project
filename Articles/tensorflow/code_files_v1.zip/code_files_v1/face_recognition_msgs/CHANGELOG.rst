^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package face_recognition_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2018-08-07)
------------------
* Update to README.md only

0.1.0 (2018-06-14)
------------------
* First formal release of the package
