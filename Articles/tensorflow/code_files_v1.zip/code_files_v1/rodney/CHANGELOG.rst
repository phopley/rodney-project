^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rodney
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Unreleased
------------------
* Set mission_running_ to false in contructor
* Added code to start mission 3 and acknowledge missions steps

0.1.1 (2018-11-12)
------------------
* Moved Arduino sketch into package
* Updates to documentation
* Moved the scaning for faces action client to rondey_missions package
* Added use of speech and facial expression
* Added rviz files for robot modelling
* Added teleop with keyboard and game controller
* Added battery status reporting
* Added wav file playback if inactive

0.1.0 (2018-06-14)
------------------
* First formal release of the package
