^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package mapping_launch
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2019-03-19)
------------------
* First formal release of the package
