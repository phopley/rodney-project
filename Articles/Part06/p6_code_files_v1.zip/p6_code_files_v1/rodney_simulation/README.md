# rodney_simulation
Rodney robot ROS simulation package
