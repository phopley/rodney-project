^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package servo_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.2 (2018-07-28)
------------------
* Update to email address in xml file

0.1.1 (2018-06-29)
------------------
* Updates to standardize documentation

0.1.0 (2018-06-14)
------------------
* First formal release of the package
