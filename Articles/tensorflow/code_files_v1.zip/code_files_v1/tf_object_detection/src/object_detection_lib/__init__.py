# __init__.py
from .object_detection_lib import ObjectDetection
