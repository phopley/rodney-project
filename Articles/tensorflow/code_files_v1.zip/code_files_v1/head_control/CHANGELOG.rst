^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package head_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Unreleased
------------------
* Removed action to scan for faces. Node now only controls servo speeds

0.1.2 (2018-09-26)
------------------
* Manual Camera movements

0.1.1 (2018-08-16)
------------------
* Update email address in package.xml file
* Moved list of seen people to this node
* Servo position velocity now ramps to avoid shuddering

0.1.0 (2018-06-14)
------------------
* First formal release of the package
