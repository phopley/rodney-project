# __init__.py
from .face_recognition_lib import FaceRecognition
