^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rodney_object_test
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2019-01-24)
------------------
* First formal release of the package
