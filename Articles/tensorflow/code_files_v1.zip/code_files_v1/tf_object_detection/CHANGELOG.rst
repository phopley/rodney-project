^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tf_object_detection
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2018-12-01)
------------------
* First formal release of the package
