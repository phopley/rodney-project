^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package thunderborg
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2019-01-28)
------------------
* Add test code file test.py
* Corrected name of function DynamicCallback from DynamicCallbak
* Corrected name circumference from circumfrence
* In thunderborg.cfg changed D-Integral to D-Derivative

0.1.0 (2019-01-23)
------------------
* First formal release of the package
